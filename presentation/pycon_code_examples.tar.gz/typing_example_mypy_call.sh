mypy typing_example.py
